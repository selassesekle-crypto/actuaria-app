# ActuarIA — Packs de données actuarielles
## Sources et descriptions

### pack_non_vie/triangles/
| Fichier | Source | Description |
|---------|--------|-------------|
| raa_mack1993.csv | CAS / chainladder | RAA — Reinsurance Association of America. Triangle de référence de Mack (1993). 10 années × 10 développements. Données réelles. |
| ukmotor_taylor_ashe.csv | chainladder | UK Motor — Taylor & Ashe (1983). 7×7. Données réelles UK. |
| genins_clark2003.csv | chainladder | General Insurance — Clark (2003). 10×10. Données réelles utilisées dans le paper Clark. |
| cas_clrd_incurloss.csv | CAS CLRD | CAS Loss Reserve Database — Sinistres déclarés. 775 compagnies × 10 dev. Données réelles USA. |
| cas_clrd_cumpaidloss.csv | CAS CLRD | CAS CLRD — Sinistres payés cumulés. Données réelles USA. |
| cas_clrd_earnedpremdir.csv | CAS CLRD | CAS CLRD — Primes acquises directes. |
| usauto_cas.csv | CAS / chainladder | US Auto — CAS. 2 branches × 10 dev. Données réelles USA. |
| rc_generale_triangle_12x12.csv | Synthétique | RC Générale France simulée. 12×12. Structure Clark Weibull (θ=4 ans, ω=1.8). |

### pack_non_vie/auto/
| Fichier | Source | Description |
|---------|--------|-------------|
| freMTPL2freq.csv | Synthétique (structure réelle) | RC Auto France — Fréquence. 50 000 polices. Structure identique au dataset freMTPL2 (Kaggle/CASdatasets). Variables : Area, VehPower, VehAge, DrivAge, BonusMalus, VehBrand, VehGas, Density, Region. |
| freMTPL2sev.csv | Synthétique (structure réelle) | RC Auto France — Sévérité. ~1 800 sinistres. Distribution log-normale calibrée sur marché français. |

### pack_non_vie/rc/
| Fichier | Source | Description |
|---------|--------|-------------|
| rc_generale_sinistres.csv | Synthétique | RC Générale — 5 000 sinistres individuels. Variables : annee_survenance, délai déclaration, coût, statut, secteur. |

### pack_vie/
| Fichier | Source | Description |
|---------|--------|-------------|
| contrats/portefeuille_vie.csv | Synthétique | 10 000 contrats vie (TemporaireDecès, VieTentière, CapitalDifféré, Rente). Variables : age, sexe, capital, prime, taux technique. |
| mortalite/td_tf_insee_2012.csv | INSEE / IA | Tables TD/TF 2012-2014 (Gompertz calibré). qx hommes et femmes, ages 0-120. |

### pack_sante_prevoyance/
| Fichier | Source | Description |
|---------|--------|-------------|
| arrets_travail/prevoyance_arrets_travail.csv | Synthétique | 8 000 arrêts de travail. Variables : age, CSP, durée, salaire journalier, franchise, indemnité. |

### pack_reglementation/
| Fichier | Source | Description |
|---------|--------|-------------|
| solvabilite2/scr_mcr_portefeuille.csv | Synthétique | 100 entités (Mutuelles/SA/IP). SCR, MCR, ratio de solvabilité, σ EIOPA par branche. |

## Notes
- Les datasets **réels** (RAA, UK Motor, GenIns, CAS CLRD, US Auto) sont des références académiques publiques issues du package Python `chainladder` et de la CAS (Casualty Actuarial Society).
- Les datasets **synthétiques** reproduisent la structure exacte des données réelles de marché français avec des paramètres calibrés sur des données publiques ACPR/FFA.
- freMTPL2 réel disponible sur Kaggle (https://www.kaggle.com/c/porto-seguro-safe-driver-prediction) et dans le package R `CASdatasets`.
